function debtCalculator(handles)
persistent S;
persistent SIndex;
S=[];
SIndex=1;
%% Parameters

A=handles.loanSlider.Value; %5500; %original amount taken out
i=handles.interestSlider.Value; %0.0505;    %interest rate
newLoanMoment=str2double(handles.newLoanTimeText.String);        %each of these are vectors that hold when loans are taken and how much they are
newLoanAmount=str2double(handles.newLoanAmountText.String);      %the values in the vectors are located based on when the user input them
nmin=0;

months=handles.monthSlider.Value;    %48;      %number of months over which the payment is made
if handles.timeFrameButton.Value==true
    nmax=months;                    %independent variables "nmax" and "P" are now defined by the "months" slider
    P=(i*A)*(1+i)^nmax/((i+1)^nmax-1);
    handles.totalPaymentText.String=num2str(P);
else
    P=handles.paymentSlider.Value;  %200;  %recurring payment amount
    nmax=(-log(1-i*A/P))/log(1+i);        %number of payments (monthly)
end

x=P/(P-(A+newLoanAmount)*i);
nmax=log(x)/log(i+1);               %same thing in the else statement (Will the months slider still work?)
Nn=nmax-nmin;
n=linspace(nmin, nmax, Nn);

year=n/12;      %vector as long as n; x-axis
%S(SIndex)=[newLoanMoment;newLoanAmount];
[row,col]=size(S);


SIndexOut=SIndex;
for j=1:Nn
    for icol=1:col
       % if j==S(1,icol)
       %     S(2,SIndex)=newLoanAmount(icol);
       %     SIndexOut=SIndex;       %so that the function will not reference an undeclared part of the vector
       %     SIndex=SIndex+1;
        %end
    end
     B(j)=A*(1+i)^n(j)-P/i*((1+i)^n(j)-1);%+S(2,SIndexOut);
end


plot(handles.debtAxes,year,B);
xlabel(handles.debtAxes,'Time (Years)');
ylabel(handles.debtAxes,'Debt Left');
axis(handles.debtAxes,[min(year) nmax/12 0 max(B)]);

handles.totalTimeText.String=num2str(Nn);
handles.additionalInterestText.String=num2str(P*Nn-A);
%disp(S(1,1));
