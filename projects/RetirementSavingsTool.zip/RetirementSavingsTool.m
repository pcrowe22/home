function varargout = RetirementSavingsTool(varargin)
% RETIREMENTSAVINGSTOOL MATLAB code for RetirementSavingsTool.fig
%      RETIREMENTSAVINGSTOOL, by itself, creates a new RETIREMENTSAVINGSTOOL or raises the existing
%      singleton*.
%
%      H = RETIREMENTSAVINGSTOOL returns the handle to a new RETIREMENTSAVINGSTOOL or the handle to
%      the existing singleton*.
%
%      RETIREMENTSAVINGSTOOL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RETIREMENTSAVINGSTOOL.M with the given input arguments.
%
%      RETIREMENTSAVINGSTOOL('Property','Value',...) creates a new RETIREMENTSAVINGSTOOL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before RetirementSavingsTool_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to RetirementSavingsTool_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help RetirementSavingsTool

% Last Modified by GUIDE v2.5 09-Apr-2019 01:30:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @RetirementSavingsTool_OpeningFcn, ...
                   'gui_OutputFcn',  @RetirementSavingsTool_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before RetirementSavingsTool is made visible.
function RetirementSavingsTool_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to RetirementSavingsTool (see VARARGIN)

% Choose default command line output for RetirementSavingsTool
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes RetirementSavingsTool wait for user response (see UIRESUME)
% uiwait(handles.figure1);
RetirementSavingsF(handles);


% --- Outputs from this function are returned to the command line.
function varargout = RetirementSavingsTool_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function initialInvestmentSlider_Callback(hObject, eventdata, handles)
% hObject    handle to initialInvestmentSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
v=handles.initialInvestmentSlider.Value;
handles.initialInvestmentText.String=num2str(v);

RetirementSavingsF(handles);

% --- Executes during object creation, after setting all properties.
function initialInvestmentSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to initialInvestmentSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function initialInvestmentText_Callback(hObject, eventdata, handles)
% hObject    handle to initialInvestmentText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of initialInvestmentText as text
%        str2double(get(hObject,'String')) returns contents of initialInvestmentText as a double
s=handles.initialInvestmentText.String;
handles.initialInvestmentSlider.Value=str2double(s);

RetirementSavingsF(handles);

% --- Executes during object creation, after setting all properties.
function initialInvestmentText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to initialInvestmentText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function annualInvestmentSlider_Callback(hObject, eventdata, handles)
% hObject    handle to annualInvestmentSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
v=handles.annualInvestmentSlider.Value;
handles.annualInvestmentText.String=num2str(v);

RetirementSavingsF(handles);

% --- Executes during object creation, after setting all properties.
function annualInvestmentSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to annualInvestmentSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function annualInvestmentText_Callback(hObject, eventdata, handles)
% hObject    handle to annualInvestmentText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of annualInvestmentText as text
%        str2double(get(hObject,'String')) returns contents of annualInvestmentText as a double
s=handles.annualInvestmentText.String;
handles.annualInvestmentSlider.Value=str2double(s);

RetirementSavingsF(handles);

% --- Executes during object creation, after setting all properties.
function annualInvestmentText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to annualInvestmentText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function interestRateSlider_Callback(hObject, eventdata, handles)
% hObject    handle to interestRateSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
v=handles.interestRateSlider.Value;
handles.interestRateText.String=num2str(v);

RetirementSavingsF(handles);

% --- Executes during object creation, after setting all properties.
function interestRateSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to interestRateSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function interestRateText_Callback(hObject, eventdata, handles)
% hObject    handle to interestRateText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of interestRateText as text
%        str2double(get(hObject,'String')) returns contents of interestRateText as a double
s=handles.interestRateText.String;
handles.interestRateSlider.Value=str2double(s);

RetirementSavingsF(handles);

% --- Executes during object creation, after setting all properties.
function interestRateText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to interestRateText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function startingAgeSlider_Callback(hObject, eventdata, handles)
% hObject    handle to startingAgeSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
v=handles.startingAgeSlider.Value;
handles.startingAgeText.String=num2str(v);

RetirementSavingsF(handles);

% --- Executes during object creation, after setting all properties.
function startingAgeSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startingAgeSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function startingAgeText_Callback(hObject, eventdata, handles)
% hObject    handle to startingAgeText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startingAgeText as text
%        str2double(get(hObject,'String')) returns contents of startingAgeText as a double
s=handles.startingAgeText.String;
handles.startingAgeSlider.Value=str2double(s);

RetirementSavingsF(handles);

% --- Executes during object creation, after setting all properties.
function startingAgeText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startingAgeText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function endingAgeSlider_Callback(hObject, eventdata, handles)
% hObject    handle to endingAgeSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
v=handles.endingAgeSlider.Value;
handles.endingAgeText.String=num2str(v);

RetirementSavingsF(handles);

% --- Executes during object creation, after setting all properties.
function endingAgeSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to endingAgeSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function endingAgeText_Callback(hObject, eventdata, handles)
% hObject    handle to endingAgeText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of endingAgeText as text
%        str2double(get(hObject,'String')) returns contents of endingAgeText as a double
s=handles.endingAgeText.String;
handles.endingAgeSlider.Value=str2double(s);

RetirementSavingsF(handles);

% --- Executes during object creation, after setting all properties.
function endingAgeText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to endingAgeText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function totalText_Callback(hObject, eventdata, handles)
% hObject    handle to totalText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of totalText as text
%        str2double(get(hObject,'String')) returns contents of totalText as a double


% --- Executes during object creation, after setting all properties.
function totalText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to totalText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
