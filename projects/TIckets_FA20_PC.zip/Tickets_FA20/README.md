# Tickets_FA20
IT Trouble Ticket Manager that connects users to a database server and allows them to edit entries through a GUI.
