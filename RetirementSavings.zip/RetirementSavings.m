function RetirementSavingsF(handles)
%% Investing Program

%% Parameters
S(1)=1000; %amount of money put into the savings account at the very start
k=100;   %money put into the account annually
r=0.06;  %interest rate

%% plotting
tStart=20;  %age I start saving
tEnd=70;    %age I stop saving
tmin=tStart-tStart;
tmax=tEnd-tStart;
Nt=tmax-tmin;
t=linspace(tmin, tmax, Nt);

for i=2:Nt
    S(i)=S(1)*exp(r*t(i))+k/r*(exp(r*t(i))-1);
end

plot(t,S);
xlabel('Time (Years)');
ylabel('Cash Money $$$');
disp(['Total money saved: ', num2str(S(Nt))]);