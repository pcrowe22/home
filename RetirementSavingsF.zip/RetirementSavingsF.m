function RetirementSavingsF(handles)
%% Investing Program

%% Parameters
S(1)=handles.initialInvestmentSlider.Value;%1000; %amount of money put into the savings account at the very start
k=handles.annualInvestmentSlider.Value;%100;   %money put into the account annually
r=handles.interestRateSlider.Value;%0.06;  %interest rate

%% plotting
tStart=handles.startingAgeSlider.Value;%20;  %age I start saving
tEnd=handles.endingAgeSlider.Value;%70;    %age I stop saving
tmin=tStart-tStart;
tmax=tEnd-tStart;
Nt=tmax-tmin;
t=linspace(tmin, tmax, Nt);

for i=2:Nt
    S(i)=S(1)*exp(r*t(i))+k/r*(exp(r*t(i))-1);
end

plot(handles.axes1,t,S);
xlabel(handles.axes1,'Time (Years)');
ylabel(handles.axes1,'Cash Money $$$');
total=num2str(round(S(Nt),2));
handles.totalText.String=total;