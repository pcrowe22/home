% function debtCalculator

clear all;
clc;

%% Parameters

A=5500; %original amount taken out
i=0.0505;    %interest rate
P=400;  %recurring payment amount

months=24;      %number of months over which the payment is made

nmin=0;
nmax=months;%(-log(1-i*A/P))/log(1+i);        %number of payments (monthly)
Nn=nmax-nmin;
n=linspace(nmin, nmax, Nn);

year=n/12;

for j=1:Nn
    B(j)=A*(1+i)^n(j)-P/i*((1+i)^n(j)-1);
end

plot(year,B);
xlabel('Time (Years)');
ylabel('Debt Left');
axis([min(year) max(year) 0 max(B)]);